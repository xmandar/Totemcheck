
-- Totem Check by Xmandar
-- Warmane / WoW 3.3.5a

local addon = CreateFrame("Frame")
local group
local active = {}
local unlocked = false
local debugMode = false

local SIZE = 42
local GAP = 12
local MAX_AGE = 120
local DEFAULT_X = 0
local DEFAULT_Y = 100

local EMPTY_ICON = "Interface\\Icons\\INV_Misc_QuestionMark"

-- One icon per element
local elements = {
    {
        name = "EARTH",
        totems = {
            "Strength of Earth Totem",
            "Stoneskin Totem",
            "Tremor Totem",
            "Earthbind Totem",
            "Stoneclaw Totem"
        }
    },
    {
        name = "FIRE",
        totems = {
            "Flametongue Totem",
            "Fire Resistance Totem",
            "Totem of Wrath",
            "Searing Totem",
            "Magma Totem",
            "Fire Elemental Totem"
        }
    },
    {
        name = "WATER",
        totems = {
            "Mana Spring Totem",
            "Mana Tide Totem",
            "Healing Stream Totem",
            "Poison Cleansing Totem",
            "Disease Cleansing Totem"
        }
    },
    {
        name = "AIR",
        totems = {
            "Windfury Totem",
            "Wrath of Air Totem",
            "Frost Resistance Totem",
            "Nature Resistance Totem",
            "Grounding Totem"
        }
    }
}

local totemAuras = {
    ["Strength of Earth Totem"] = {"Strength of Earth"},
    ["Stoneskin Totem"] = {"Stoneskin"},
    ["Windfury Totem"] = {"Windfury", "Windfury Totem"},
    ["Wrath of Air Totem"] = {"Wrath of Air Totem"},
    ["Mana Spring Totem"] = {"Mana Spring"},
    ["Mana Tide Totem"] = {"Mana Tide"},
    ["Healing Stream Totem"] = {
        "Healing Stream Totem",
        "Healing Stream"
    },
    ["Flametongue Totem"] = {"Flametongue Totem"},
    ["Fire Resistance Totem"] = {"Fire Resistance"},
    ["Frost Resistance Totem"] = {"Frost Resistance"},
    ["Nature Resistance Totem"] = {"Nature Resistance"},
    ["Totem of Wrath"] = {"Totem of Wrath"},
    ["Tremor Totem"] = {},
    ["Grounding Totem"] = {},
    ["Earthbind Totem"] = {},
    ["Stoneclaw Totem"] = {},
    ["Searing Totem"] = {},
    ["Magma Totem"] = {},
    ["Fire Elemental Totem"] = {},
    ["Poison Cleansing Totem"] = {},
    ["Disease Cleansing Totem"] = {}
}

local aliases = {
    ["strength of earth"] = "Strength of Earth Totem",
    ["stoneskin"] = "Stoneskin Totem",
    ["windfury"] = "Windfury Totem",
    ["wrath of air"] = "Wrath of Air Totem",
    ["mana spring"] = "Mana Spring Totem",
    ["mana tide"] = "Mana Tide Totem",
    ["healing stream"] = "Healing Stream Totem",
    ["flametongue"] = "Flametongue Totem",
    ["fire resistance"] = "Fire Resistance Totem",
    ["frost resistance"] = "Frost Resistance Totem",
    ["nature resistance"] = "Nature Resistance Totem",
    ["totem of wrath"] = "Totem of Wrath",
    ["tremor"] = "Tremor Totem",
    ["grounding"] = "Grounding Totem",
    ["earthbind"] = "Earthbind Totem",
    ["stoneclaw"] = "Stoneclaw Totem",
    ["searing"] = "Searing Totem",
    ["magma"] = "Magma Totem",
    ["fire elemental"] = "Fire Elemental Totem",
    ["poison cleansing"] = "Poison Cleansing Totem",
    ["disease cleansing"] = "Disease Cleansing Totem"
}

local elementFrames = {}

local function NormalizeName(name)
    return string.lower(tostring(name or ""))
end

local function FindTotem(spellName, destName)
    local names = {
        NormalizeName(spellName),
        NormalizeName(destName)
    }

    for _, name in ipairs(names) do
        if name ~= "" then
            for alias, totemName in pairs(aliases) do
                if string.find(name, alias, 1, true) then
                    return totemName
                end
            end

            for _, element in ipairs(elements) do
                for _, totemName in ipairs(element.totems) do
                    if name == NormalizeName(totemName) then
                        return totemName
                    end
                end
            end
        end
    end

    return nil
end

local function GetElementForTotem(totemName)
    for index, element in ipairs(elements) do
        for _, name in ipairs(element.totems) do
            if name == totemName then
                return index
            end
        end
    end

    return nil
end

local function IsRaidMember(flags)
    if not flags then return false end
    return bit.band(flags, 0x7) ~= 0
end

local function FindTotemAura(totemName)
    local auraList = totemAuras[totemName]

    if not auraList or #auraList == 0 then
        return false
    end

    for i = 1, 40 do
        local auraName = UnitBuff("player", i)

        if not auraName then
            break
        end

        for _, expectedName in ipairs(auraList) do
            if auraName == expectedName then
                return true
            end
        end
    end

    return false
end

local function CreateGroup()
    TotemIconsDB = TotemIconsDB or {}

    group = CreateFrame(
        "Frame",
        "TotemCheckByXmandar",
        UIParent
    )

    local groupWidth = 4 * SIZE + 3 * GAP

    group:SetWidth(groupWidth)
    group:SetHeight(58)
    group:SetMovable(true)
    group:EnableMouse(true)
    group:RegisterForDrag("LeftButton")
    group:SetClampedToScreen(true)

    group:SetPoint(
        "CENTER",
        UIParent,
        "CENTER",
        TotemIconsDB.x or DEFAULT_X,
        TotemIconsDB.y or DEFAULT_Y
    )

    group:SetScript("OnDragStart", function(self)
        if unlocked then
            self:StartMoving()
        end
    end)

    group:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()

        local centerX, centerY = self:GetCenter()

        TotemIconsDB.x =
            centerX - UIParent:GetWidth() / 2

        TotemIconsDB.y =
            centerY - UIParent:GetHeight() / 2
    end)

    local title = group:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormal"
    )

    title:SetWidth(groupWidth)
    title:SetHeight(18)
    title:SetPoint("TOP", group, "TOP", 0, 0)
    title:SetJustifyH("CENTER")
    title:SetText("Totem Check by Xmandar")

    for index, element in ipairs(elements) do
        local x = (index - 1) * (SIZE + GAP)

        local heading = group:CreateFontString(
            nil,
            "OVERLAY",
            "GameFontNormalSmall"
        )

        heading:SetWidth(SIZE)
        heading:SetHeight(14)
        heading:SetPoint(
            "TOPLEFT",
            group,
            "TOPLEFT",
            x,
            -16
        )
        heading:SetJustifyH("CENTER")
        heading:SetText(element.name)

        local frame = CreateFrame("Frame", nil, group)
        frame:SetWidth(SIZE)
        frame:SetHeight(SIZE)
        frame:SetPoint(
            "TOPLEFT",
            group,
            "TOPLEFT",
            x,
            -30
        )

        local texture = frame:CreateTexture(nil, "ARTWORK")
        texture:SetAllPoints(frame)
        texture:SetTexture(EMPTY_ICON)
        texture:SetDesaturated(true)
        texture:SetVertexColor(0.55, 0.55, 0.55, 0.45)

        frame.texture = texture
        frame.elementIndex = index
        frame.totemName = nil

        frame:EnableMouse(true)
        frame:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")

            if self.totemName then
                GameTooltip:SetText(element.name .. ": " .. self.totemName)
            else
                GameTooltip:SetText(element.name .. ": No active totem")
            end

            GameTooltip:Show()
        end)

        frame:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)

        elementFrames[index] = frame
    end
end

local function UpdateIcons()
    if not group then return end

    local now = GetTime()
    local selected = {}

    for index = 1, 4 do
        selected[index] = nil
    end

    -- Choose the newest active totem for each element
    for guid, data in pairs(active) do
        if data.expires <= now then
            active[guid] = nil
        else
            local elementIndex = GetElementForTotem(data.name)

            if elementIndex then
                local old = selected[elementIndex]

                if not old or data.time > old.time then
                    selected[elementIndex] = data
                end
            end
        end
    end

    -- Update exactly four icons
    for index, frame in ipairs(elementFrames) do
        local data = selected[index]

        if data then
            frame.totemName = data.name

            if data.icon then
                frame.texture:SetTexture(data.icon)
            else
                frame.texture:SetTexture(EMPTY_ICON)
            end

            local inRange = FindTotemAura(data.name)

            frame.texture:SetDesaturated(not inRange)
            frame.texture:SetVertexColor(1, 1, 1, 1)
        else
            frame.totemName = nil
            frame.texture:SetTexture(EMPTY_ICON)
            frame.texture:SetDesaturated(true)
            frame.texture:SetVertexColor(0.55, 0.55, 0.55, 0.45)
        end

        frame:Show()
    end
end

local function HandleCombatLog(...)
    local timestamp, event,
        sourceGUID, sourceName, sourceFlags,
        destGUID, destName, destFlags,
        spellID, spellName = ...

    if event == "SPELL_SUMMON" then
        if debugMode then
            print("|cffffff00[TOTEM DEBUG]|r SUMMON")
            print("Source: " .. tostring(sourceName))
            print("Destination: " .. tostring(destName))
            print("Spell ID: " .. tostring(spellID))
            print("Spell Name: " .. tostring(spellName))
        end

        if not IsRaidMember(sourceFlags) then
            return
        end

        if not destGUID then return end

        local spellInfoName, rank, icon = GetSpellInfo(spellID)

        local name = FindTotem(
            spellName or spellInfoName,
            destName
        )

        if not name then
            if debugMode then
                print("|cffff0000Totem not recognized!|r")
            end
            return
        end

        local elementIndex = GetElementForTotem(name)
        if not elementIndex then return end

        active[destGUID] = {
            name = name,
            icon = icon,
            owner = sourceName or "?",
            time = GetTime(),
            expires = GetTime() + MAX_AGE
        }

        if debugMode then
            print("|cff00ff00Totem detected: " .. name .. "|r")
        end

        UpdateIcons()

    elseif event == "UNIT_DIED"
        or event == "UNIT_DESTROYED"
        or event == "UNIT_DISSIPATES" then

        if destGUID and active[destGUID] then
            active[destGUID] = nil
            UpdateIcons()
        end
    end
end

addon:RegisterEvent("ADDON_LOADED")
addon:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
addon:RegisterEvent("PLAYER_ENTERING_WORLD")
addon:RegisterEvent("UNIT_AURA")

addon:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local name = ...

        if name == "TotemIcons" then
            CreateGroup()
            UpdateIcons()
        end

    elseif event == "COMBAT_LOG_EVENT_UNFILTERED" then
        HandleCombatLog(...)

    elseif event == "UNIT_AURA" then
        local unit = ...

        if unit == "player" then
            UpdateIcons()
        end

    elseif event == "PLAYER_ENTERING_WORLD" then
        UpdateIcons()
    end
end)

addon:SetScript("OnUpdate", function(self, elapsed)
    self.timer = (self.timer or 0) + elapsed

    if self.timer >= 0.5 then
        self.timer = 0

        local now = GetTime()

        for guid, data in pairs(active) do
            if data.expires <= now then
                active[guid] = nil
            end
        end

        UpdateIcons()
    end
end)

SLASH_TOTEMCHECK1 = "/tc"

SlashCmdList["TOTEMCHECK"] = function(msg)
    msg = string.lower(msg or "")

    if msg == "unlock" then
        unlocked = true
        print("|cff00ff00Totem Check: Unlocked|r")

    elseif msg == "lock" then
        unlocked = false
        print("|cffff0000Totem Check: Locked|r")

    elseif msg == "reset" then
        TotemIconsDB = TotemIconsDB or {}
        TotemIconsDB.x = DEFAULT_X
        TotemIconsDB.y = DEFAULT_Y
        ReloadUI()

    elseif msg == "clear" then
        active = {}
        UpdateIcons()
        print("Totem Check: Cleared")

    elseif msg == "debug" then
        debugMode = not debugMode
        print("Totem Check Debug: " .. tostring(debugMode))

    else
        print("|cffffff00Totem Check by Xmandar|r")
        print("/tc unlock")
        print("/tc lock")
        print("/tc reset")
        print("/tc clear")
        print("/tc debug")
    end
end
